package com.example.demo;

import org.springframework.data.cassandra.repository.CassandraRepository;

public interface SampleRepository extends CassandraRepository<SampleEntity, String> {
}
