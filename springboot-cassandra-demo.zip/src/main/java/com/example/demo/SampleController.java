package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class SampleController {

    private final SampleRepository repository;

    public SampleController(SampleRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/all")
    public List<SampleEntity> getAll() {
        return repository.findAll();
    }

    @GetMapping("/count")
    public long getCount() {
        return repository.count();
    }
}
