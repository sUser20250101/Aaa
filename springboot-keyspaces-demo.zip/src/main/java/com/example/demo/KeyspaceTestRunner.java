package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.cassandra.core.CassandraTemplate;

@Component
public class KeyspaceTestRunner implements CommandLineRunner {

    @Autowired
    private CassandraTemplate cassandraTemplate;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Connected to AWS Keyspaces!");
        cassandraTemplate.getCqlOperations().execute("SELECT release_version FROM system.local")
            .forEach(row -> System.out.println("Cassandra Release Version: " + row.getString("release_version")));
    }
}
