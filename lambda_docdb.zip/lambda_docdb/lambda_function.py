import pymongo

def lambda_handler(event, context):
    # DocumentDB connection settings
    username = "your_docdb_username"
    password = "your_docdb_password"
    cluster_endpoint = "your-cluster-name.cluster-xxxxxx.us-east-1.docdb.amazonaws.com"
    port = 27017
    db_name = "your_database_name"
    collection_name = "your_collection"

    uri = f"mongodb://{username}:{password}@{cluster_endpoint}:{port}/?ssl=true&retryWrites=false"

    try:
        client = pymongo.MongoClient(
            uri,
            ssl=True,
            ssl_ca_certs="./rds-combined-ca-bundle.pem",
            serverSelectionTimeoutMS=5000
        )

        db = client[db_name]
        collection = db[collection_name]

        result = collection.insert_one({"hello": "world"})
        return {
            "status": "success",
            "inserted_id": str(result.inserted_id)
        }

    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }

